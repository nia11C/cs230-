
let pace = 0;
let record = 0;
let input = [];
let randomColours = [];
const circles = ['circle1', 'circle2', 'circle3', 'circle4']; 

//Called when start button is clicked
function startButton(){
    randomColours = []; //empty array for pattern of circles
    input = []; //empty array for user input
    pace = 800;
    document.getElementById('Score').innerHTML = 0; //Set current score to 0
    document.getElementById("go_circle").style.backgroundColor="green"; //Change light to green
   
    setTimeout(function () {
        nextLevel()
    }, 3000); //Begin game 3 seconds after the light turns green
}

//Generate a random number between 0 and 3 to decide which circle to flash
function pickNextCircle() {
    let randomNumber = Math.floor(Math.random() * 4);
    return randomNumber;
}

//If user gets previous level correct this method is called
function nextLevel() {
    const nextCircle = pickNextCircle();
    randomColours.push(nextCircle)
    if (randomColours.length == 5 || randomColours.length == 9 || randomColours.length == 13) {
        pace -= 250;
    }
    for (let i = 0; i< randomColours.length; i++) {
        const x = randomColours[i];
        setTimeout(function () {
            circlePattern(x)
        }, pace  * i) 
    }

}

//Flash circles
function circlePattern(buttonId){ 
    document.getElementById(buttonId).classList.remove(circles[buttonId]);      
    setTimeout(function() {
        document.getElementById(buttonId).classList.add(circles[buttonId])
    }, pace - 200); 
}

//Check if user input and shown pattern match
function compareArrays() {
    const y = input.length - 1; 
    if(input[y] != randomColours[y]) {
        highestScore();
        wrongInput();
        reset();
    } else if (input.length == randomColours.length) {
        document.getElementById('Score').innerHTML = input.length  
        input = [] 
        nextLevel();
    }
}

//Keep track of points during game
function points(button){      
    let circleId = button.getAttribute('id'); 
    input.push(circleId);
    circlePattern(circleId);
    setTimeout(compareArrays, 2000)
    //nextLevel();
    //noResponse();
} 

//Set highest score
function highestScore() {
    record = Math.max(parseInt(document.getElementById('Score').innerHTML), record);
    document.getElementById('HighScore').innerHTML =  record;
}

//If the users input does not match the shown pattern
function wrongInput() {
    for(let i = 0; i < 5; i++) {
        setTimeout(endGame, 1000 * i);
    }
}

//Flashes circles if player has not responded after 5 seconds.
// function noResponse() {
//     setTimeout(function() {
//       if (input.length > 0 && input.length === randomColours.length) {
//         return;
//       }
    
//       for (let i = 0; i < 5; i++) {
//         setTimeout(function() {
//           for (let j = 0; j < 4; j++) {
//             circlePattern(j);
//           }
//         }, 1000 * i);
//       }
      
//       setTimeout(function() {
//         reset();
//       }, 1000);
//     }, 5000);
//   }
  

  
//End the game
function endGame() {
    pace = 800;
    for(let i = 0; i < 4; i++) {
        circlePattern(i);
    }
}

//Reset the game
function reset() {
    document.getElementById("go_circle").style.backgroundColor="red";
}







