var data1 = 0;
var data2 = 0;
var data3 = 0;
var data4 = 0;
var data5 = 0;
var data6 = 0;
document.getElementById("level_1").innerText=data1;
function increment()
{
    data1=data1+1;
    document.getElementById("level_1").innerText=data1;
}

function decrement()
{
    data1=Math.max(0,data1-1);
    document.getElementById("level_1").innerText=data1;
}


document.getElementById("level_2").innerText=data2;
function increment2()
{
    data2=data2+1;
    document.getElementById("level_2").innerText=data2;
}

function decrement2()
{
    data2=Math.max(0,data2-1);
    document.getElementById("level_2").innerText=data2;
}

document.getElementById("level_3").innerText=data3;
function increment3()
{
    data3=data3+1;
    document.getElementById("level_3").innerText=data3;
}

function decrement3()
{
    data3=Math.max(0,data3-1);
    document.getElementById("level_3").innerText=data3;
}

document.getElementById("level_4").innerText=data4;
function increment4()
{
    data4=data4+1;
    document.getElementById("level_4").innerText=data4;
}

function decrement4()
{
    data4=Math.max(0,data4-1);
    document.getElementById("level_4").innerText=data4;
}

document.getElementById("level_5").innerText=data5;
function increment5()
{
    data5=data5+1;
    document.getElementById("level_5").innerText=data5;
}

function decrement5()
{
    data5=Math.max(0,data5-1);
    document.getElementById("level_5").innerText=data5;
}

document.getElementById("level_6").innerText=data6;
function increment6()
{
    data6=data6+1;
    document.getElementById("level_6").innerText=data6;
}

function decrement6()
{
    data6=Math.max(0,data6-1);
    document.getElementById("level_6").innerText=data6;
}