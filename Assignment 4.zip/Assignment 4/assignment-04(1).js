//This is the backend for the user TABLE
//Couldn't get the front end working but this back end works through the terminal.


var mysql = require('mysql');
var readline = require('readline');

var con = mysql.createConnection({
  host: "localhost",
  user: "user1",
  password: "user1",
  database: "user1"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

  var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.question("Enter command (create/read/update/delete): ", function(command) {
    if (command === "create") {
      //rl.question("Enter Title: ", function(title) {
        rl.question("Enter Title: ", function(title) {
            // Convert title to lowercase for easier comparison
            title = title.toLowerCase();
            
            // Check if title is valid
            if (title === "mr" || title === "ms" || title === "mrs" || title === "miss" || title === "mx" || title === "dr") {
              rl.question("Enter First Name: ", function(firstName) {
                rl.question("Enter Surname: ", function(surname) {
                  rl.question("Enter Mobile: ", function(mobile) {
                    rl.question("Enter Email Address: ", function(email) {
                      //CREATE
                      var insertSql = "INSERT INTO `user`(`Title`, `First Name`, `Surname`, `Mobile`, `Email Address`) VALUES (?, ?, ?, ?, ?)";
                      var values = [title, firstName, surname, mobile, email];
                      con.query(insertSql, values, function (err, result) {
                        if (err) throw err;
                        console.log("1 record inserted");
                        rl.close();
                      });
                    });
                  });
                });
              });
            } else {
              console.log("Invalid title(Must be one of the following: Mr/Ms/Mrs/Miss/Mx/Dr)");
              rl.close();
            }
          });
          
    //     rl.question("Enter First Name: ", function(firstName) {
    //       rl.question("Enter Surname: ", function(surname) {
    //         rl.question("Enter Mobile: ", function(mobile) {
    //           rl.question("Enter Email Address: ", function(email) {

    //             //CREATE
    //             var insertSql = "INSERT INTO `user`(`Title`, `First Name`, `Surname`, `Mobile`, `Email Address`) VALUES (?, ?, ?, ?, ?)";
    //             var values = [title, firstName, surname, mobile, email];
    //             con.query(insertSql, values, function (err, result) {
    //               if (err) throw err;
    //               console.log("1 record inserted");
    //               rl.close();
    //             });
    //           });
    //         });
    //       });
    //     });
    //   });
    } else if (command === "read") {
      //READ
    //   var selectSql = "SELECT * FROM `user`";
    //   con.query(selectSql, function (err, result, fields) {
    //     if (err) throw err;
    //     console.log(result);
    //     rl.close();
    //   });

    rl.question("Enter the first name of the person you are searching for: ", function(name) {
        var selectSql = "SELECT * FROM `user` WHERE `First Name` = ? ORDER BY RAND()";
      
        con.query(selectSql, [name], function (err, result, fields) {
          if (err) throw err;
          console.log(result);
          rl.close();
        });
      });
    } 
    
    else if (command === "update") {
    rl.question("Enter aspect to update (Title/Mobile/EmailAddress): ", function(aspect1) {
        if(aspect1 === "Title"){
            rl.question("Enter Email Address: ", function(EmailAddress) {
              rl.question("Enter new Title: ", function(newTitle) {
      
                //UPDATE
                var updateSql = "UPDATE `user` SET `Title`=? WHERE `Email Address`=?";
                var updateValues = [newTitle, EmailAddress];
                con.query(updateSql, updateValues, function (err, result) {
                  if (err) throw err;
                  console.log(result.affectedRows + " record(s) updated");
                  rl.close();
                });
              });
            });
          }

    //     else if(aspect1 === "FirstName"){
    //         rl.question("Enter Email Address: ", function(EmailAddress) {
    //         rl.question("Enter new First Name: ", function(newFirstName) {

    //       //UPDATE
    //         var updateSql = "UPDATE `user` SET `First Name`=? WHERE `Email Address`=?";
    //         var updateValues = [newFirstName, EmailAddress];
    //         con.query(updateSql, updateValues, function (err, result) {
    //         if (err) throw err;
    //         console.log(result.affectedRows + " record(s) updated");
    //         rl.close();
    //       });
    //     });
    //   });
    // }

    // else if(aspect1 === "Surname"){
    //     rl.question("Enter Email Address: ", function(EmailAddress) {
    //       rl.question("Enter new Surname: ", function(newSurname) {
  
    //         //UPDATE
    //         var updateSql = "UPDATE `user` SET `Surname`=? WHERE `Email Address`=?";
    //         var updateValues = [newSurname, EmailAddress];
    //         con.query(updateSql, updateValues, function (err, result) {
    //           if (err) throw err;
    //           console.log(result.affectedRows + " record(s) updated");
    //           rl.close();
    //         });
    //       });
    //     });
    //   }

      else if(aspect1 === "Mobile"){
        rl.question("Enter Email Address: ", function(EmailAddress) {
          rl.question("Enter new Mobile Number: ", function(newMobile) {
  
            //UPDATE
            var updateSql = "UPDATE `user` SET `Mobile`=? WHERE `Email Address`=?";
            var updateValues = [newMobile, EmailAddress];
            con.query(updateSql, updateValues, function (err, result) {
              if (err) throw err;
              console.log(result.affectedRows + " record(s) updated");
              rl.close();
            });
          });
        });
      }

      else if(aspect1 === "EmailAddress"){
        rl.question("Enter Email Address: ", function(EmailAddress) {
          rl.question("Enter new Email Address: ", function(newEmail) {
  
            //UPDATE
            var updateSql = "UPDATE `user` SET `Email Address`=? WHERE `Email Address`=?";
            var updateValues = [newEmail, EmailAddress];
            con.query(updateSql, updateValues, function (err, result) {
              if (err) throw err;
              console.log(result.affectedRows + " record(s) updated");
              rl.close();
            });
          });
        });
      }

      else {
        console.log("Invalid command");
        rl.close();
      }
});


    } else if (command === "delete") {
    //   rl.question("Enter Email Address of the account you wish to delete: ", function(EmailAddress) {

    //     //DELETE
    //     var deleteSql = "DELETE FROM `user` WHERE `Email Address`=?";
    //     con.query(deleteSql, [EmailAddress], function (err, result) {
    //       if (err) throw err;
    //       console.log(result.affectedRows + " record(s) deleted");
    //       rl.close();
    //     });
    //   });

    rl.question("Enter email, phone, and FIRST name of the account you wish to delete (SEPARATE EACH INPUT WITH A COMMA AND DO NOT USE SPACES AFTER EACH COMMA): ", function(input) {
        var [email, phone, name] = input.split(",");
        var deleteSql = "DELETE FROM `user` WHERE `Email Address`=? AND `Mobile`=? AND `First Name`=?";
      
        con.query(deleteSql, [email, phone, name], function (err, result) {
          if (err) throw err;
          console.log(result.affectedRows + " record(s) deleted");
          rl.close();
        });
      });
      
    } else {
      console.log("Invalid command");
      rl.close();
    }
  });
});


