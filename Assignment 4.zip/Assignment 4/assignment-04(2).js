//This is the backend for the home address TABLE
//Couldn't get the front end working but this back end works through the terminal.

var mysql = require('mysql');
var readline = require('readline');

var con = mysql.createConnection({
  host: "localhost",
  user: "user1",
  password: "user1",
  database: "user1"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

  var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.question("Enter command (create/read/update/delete): ", function(command) {
    if (command === "create") {
      rl.question("Enter Address Line 1: ", function(addressLine1) {
        rl.question("Enter Address Line 2: ", function(addressLine2) {
          rl.question("Enter Town: ", function(town) {
            rl.question("Enter County/City: ", function(county) {
              rl.question("Enter Eircode: ", function(eircode) {

                //CREATE
                var insertSql = "INSERT INTO `home address`(`Address Line 1`, `Address Line 2`, `Town`, `County/City`, `Eircode`) VALUES (?, ?, ?, ?, ?)";
                var values = [addressLine1, addressLine2, town, county, eircode];
                con.query(insertSql, values, function (err, result) {
                  if (err) throw err;
                  console.log("1 record inserted");
                  rl.close();
                });
              });
            });
          });
        });
      });
    } else if (command === "read") {
      //READ
      var selectSql = "SELECT * FROM `home address`";
      con.query(selectSql, function (err, result, fields) {
        if (err) throw err;
        console.log(result);
        rl.close();
      });
    } 
    
    else if (command === "update") {
    rl.question("Enter aspect to update (AddressLine1/AddressLine2/Town/County/Eircode): ", function(aspect1) {
        if(aspect1 === "AddressLine1"){
            rl.question("Enter Eircode: ", function(eircode) {
              rl.question("Enter new Address Line 1: ", function(newAddressLine1) {
      
                //UPDATE
                var updateSql = "UPDATE `home address` SET `Address Line 1`=? WHERE `Eircode`=?";
                var updateValues = [newAddressLine1, eircode];
                con.query(updateSql, updateValues, function (err, result) {
                  if (err) throw err;
                  console.log(result.affectedRows + " record(s) updated");
                  rl.close();
                });
              });
            });
          }

        else if(aspect1 === "AddressLine2"){
            rl.question("Enter Eircode: ", function(eircode) {
            rl.question("Enter new Address Line 2: ", function(newAddressLine2) {

          //UPDATE
            var updateSql = "UPDATE `home address` SET `Address Line 2`=? WHERE `Eircode`=?";
            var updateValues = [newAddressLine2, eircode];
            con.query(updateSql, updateValues, function (err, result) {
            if (err) throw err;
            console.log(result.affectedRows + " record(s) updated");
            rl.close();
          });
        });
      });
    }

    else if(aspect1 === "Town"){
        rl.question("Enter Eircode: ", function(eircode) {
            rl.question("Enter new Town: ", function(newTown) {
                //UPDATE
                  var updateSql = "UPDATE `home address` SET `Town`=? WHERE `Eircode`=?";
                  var updateValues = [newTown, eircode];
                  con.query(updateSql, updateValues, function (err, result) {
                  if (err) throw err;
                  console.log(result.affectedRows + " record(s) updated");
                  rl.close();
                });
              });
            });
          }

          else if(aspect1 === "County"){
            rl.question("Enter Eircode: ", function(eircode) {
                rl.question("Enter new County/City: ", function(newCounty) {
                    //UPDATE
                      var updateSql = "UPDATE `home address` SET `County/City`=? WHERE `Eircode`=?";
                      var updateValues = [newCounty, eircode];
                      con.query(updateSql, updateValues, function (err, result) {
                      if (err) throw err;
                      console.log(result.affectedRows + " record(s) updated");
                      rl.close();
                    });
                  });
                });
              }

              else if(aspect1 === "Eircode"){
                rl.question("Enter old Eircode: ", function(eircode) {
                    rl.question("Enter new Eircode: ", function(newEircode) {
                        //UPDATE
                          var updateSql = "UPDATE `home address` SET `Eircode`=? WHERE `Eircode`=?";
                          var updateValues = [newEircode, eircode];
                          con.query(updateSql, updateValues, function (err, result) {
                          if (err) throw err;
                          console.log(result.affectedRows + " record(s) updated");
                          rl.close();
                        });
                      });
                    });
                  }
            else {
                console.log("Invalid command");
                rl.close();
              }
            });
          } else if (command === "delete") {
            rl.question("Enter Eircode: ", function(eircode) {
      
              //DELETE
              var deleteSql = "DELETE FROM `home address` WHERE `Eircode`=?";
              var deleteValues = [eircode];
              con.query(deleteSql, deleteValues, function (err, result) {
                if (err) throw err;
                console.log(result.affectedRows + " record(s) deleted");
                rl.close();
              });
            });
          } else {
            console.log("Invalid command");
            rl.close();
          }
        });
      });
      